$(function show() 
    
    $(document.getElementById('sidebar').classList.toggle('active'));
